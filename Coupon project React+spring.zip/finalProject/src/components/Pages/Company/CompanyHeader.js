import Logout from "../Logout";
import classes from "./CompanyHeader.module.css";
import Managment from "../Company/Managment";

const CompanyHeader = () => {
  return (
    <>
      <div className={classes.header}>
        <h1>Company Page</h1>
        <Logout />
        <Managment />
      </div>
    </>
  );
};

export default CompanyHeader;