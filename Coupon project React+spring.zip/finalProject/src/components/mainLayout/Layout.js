import { Fragment } from "react";
import { useSelector } from "react-redux";
import Header from "../Header/Header";
import classes from "./Layout.module.css"
import Admin from "../Pages/Admin/Admin";


const Layout = (props)=>{
    const clientType = useSelector(state=>state.auth.clientType)
    console.log(clientType);
    return <Fragment>
    {clientType==="administrator"?<Admin/>:<Header></Header>}
        
        <main className = {classes.main}>{props.children}</main>
        
    </Fragment>
};
export default Layout;