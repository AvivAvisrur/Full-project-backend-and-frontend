package com.project2.project2.controller;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.project2.project2.Beans.Coupon;
import com.project2.project2.Beans.Customer;
import com.project2.project2.Exceptions.CompanyUserException;
import com.project2.project2.Exceptions.CustomerUserException;
import com.project2.project2.Repositories.CouponRepo;
import com.project2.project2.Service.GuestService;
import com.project2.project2.Util.JWTutil;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 *
 * This class is in charge of all the VERBS that we use with our external servers.
 * It has 1 VERB of type POST to get company all coupons.
 * It is in charge of handling REST API requests and returning the response.
 *
 */
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RestController
@RequestMapping("/Guest")
@RequiredArgsConstructor
public class GuestController {
    private final GuestService guestService;
    private final JWTutil jwTutil;


    /**
     * This verb enable  to get all the coupons to the system from external server.
     *
     *
     * @return ResponseEntity<> with the list of coupons and HTTP status.
     *
     *
     */
    @PostMapping("/getAllCoupons")
    private ResponseEntity<?>getAllCoupons(){
        return new ResponseEntity<>(guestService.getAllCoupons(),HttpStatus.OK);
    }
    @PostMapping("/addCustomer")
    private ResponseEntity<?>addCustomer(@RequestBody Customer customer) throws CustomerUserException {
        System.out.println(customer);
            try {
                guestService.addCustomer(customer);
                return new ResponseEntity<>("Customer has been added", HttpStatus.CREATED);
            } catch (DataIntegrityViolationException e) {
                throw new CustomerUserException(e.getMessage());
            }
        }
}
