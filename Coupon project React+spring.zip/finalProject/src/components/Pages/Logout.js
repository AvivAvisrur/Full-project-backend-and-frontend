
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { authActions } from '../../store/auth-slice';

const Logout = () => {
    const history = useHistory();
    const dispatch = useDispatch();

    const onClickHandler = ()=>{
        dispatch(authActions.logout());
        history.push("/home");
    }

    return (
        <button onClick={onClickHandler}>Logout</button>
    );
};

export default Logout;