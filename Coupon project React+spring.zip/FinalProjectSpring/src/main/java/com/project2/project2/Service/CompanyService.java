package com.project2.project2.Service;


import com.project2.project2.Beans.Category;
import com.project2.project2.Beans.Company;
import com.project2.project2.Beans.Coupon;
import com.project2.project2.Beans.Customer;
import com.project2.project2.Exceptions.CompanyUserException;
import com.project2.project2.Exceptions.CouponException;


import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;



import java.util.List;

/**
 * This class extends another abstract class.
 * This class has methods that unable company to login the system of purchasing coupons from few different types,
 * adding coupons, delete , update, and getting coupons.
 *
 * This class has 1 attribute from type int. which represents the id number of the company who can sell coupon
 */

@Service
public class CompanyService extends ClientService{
    private long companyId;

    /**
     * This method enable login of company to the system.
     *
     * @param email    of the company who tries to login.
     * @param password of the company who tries to login.
     * @return boolean value. true if the company succeed to login and false if he could not.
     * @throws CompanyUserException
     */
    @Override
    public boolean login(String email, String password) throws CompanyUserException {
        try {
            companyId = companyRepo.findByEmailAndPassword(email, password).getId();
            System.out.println("Logged in successfully");
            return true;
        }catch (NullPointerException e){
            System.out.println("Company is not exists!");
        }
        return false;
    }

    /**
     * This method enable the company to add coupon  to the system.
     *
     * @param coupon of the company.
     * @throws CouponException
     */
    public void addCoupon(Coupon coupon) throws CouponException {
        try {
            coupon.setCompanyId(companyId);
            couponRepo.save(coupon);
            System.out.println("Coupon added successfully to the company!");
        }catch (DataIntegrityViolationException e){
           throw new CouponException("You cant have 2 titles with the same descriptions!");
        }
    }

    /**
     * This method allow the company to update coupon from their list.
     *
     * @param coupon of the company.
     * @throws CouponException
     */
    public void updateCoupon(Coupon coupon) throws CouponException {
        if(!couponRepo.existsById(coupon.getId())){
            throw new CouponException("Coupon not exists!");
        }
        Coupon updateCoupon = couponRepo.findById(coupon.getId());
        updateCoupon.setAmount(coupon.getAmount());
        updateCoupon.setCategory(coupon.getCategory());
        updateCoupon.setImage(coupon.getImage());
        updateCoupon.setDescription(coupon.getDescription());
        updateCoupon.setEndDate(coupon.getEndDate());
        updateCoupon.setStartDate(coupon.getStartDate());
        couponRepo.saveAndFlush(updateCoupon);
        System.out.println("Coupon updated!");
    }

    /**
     * This method allow the company to delete coupon  from the system.
     *
     * @param couponID of the coupon.
     * @throws CouponException
     */
    public void deleteCoupon(long couponID) throws CouponException {
        if(!couponRepo.existsById(couponID)){
            throw new CouponException("Coupon does not exists");
        }
        Coupon coupon= couponRepo.findById(couponID);
        for (Customer customer : coupon.getCustomers()) {
            List<Coupon> coupons = customer.getCoupons();
            int index = coupons.indexOf(coupon);
            customer.getCoupons().remove(index);
            customerRepo.saveAndFlush(customer);

        }

        couponRepo.deleteById(couponID);
        System.out.println("Coupon deleted successfully!");

    }

    /**
     * This method allow the company to see all the  coupons that registered on their id.
     *
     * @return all the coupons of the company we asked by the id
     * @throws CompanyUserException
     */
    public List<Coupon> getCompanyCoupons() throws CompanyUserException {
        if(companyRepo.findById(companyId).getCoupons().isEmpty()){
            throw new CompanyUserException("This company has no coupons");
        }
        return companyRepo.findById(companyId).getCoupons();
    }

    /**
     * This method allow the company to see all the  coupons by their categories that regiestered on their id.
     *
     * @param category the id of the category of the coupons belongs to the company.
     * @return all the coupons in the same category
     * @throws CompanyUserException
     */
    public List<Coupon>getCompanyCouponsByCategory(Category category) throws CompanyUserException {
        if(couponRepo.findCouponsByCompanyIdAndCategory(companyId,category).isEmpty()){
            throw new CompanyUserException("This company dont have coupons in this category!");
        }
      return  couponRepo.findCouponsByCompanyIdAndCategory(companyId,category);
    }

    /**
     * This method allow the company to see all the  coupons by their max price that registered on their id.
     *
     * @param maxprice the   max price u looking for to show the coupons between the range of price.
     * @return all the coupons within the price.
     * @throws CompanyUserException
     */
    public List<Coupon>getCompanyCouponsByMaxPrice(double maxprice) throws CompanyUserException {
        if(couponRepo.findByCompanyIdAndPriceLessThanEqual(companyId,maxprice).isEmpty()){
            throw new CompanyUserException("This company coupons dont have coupons in this price range!");
        }
        return couponRepo.findByCompanyIdAndPriceLessThanEqual(companyId,maxprice);
    }

    /**
     * This method gives all the details of the company.
     *
     * @return the company by the id
     */
    public Company getCompanyDetails(){
        return companyRepo.findById(companyId);
    }


}
