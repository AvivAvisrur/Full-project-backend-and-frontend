import classes from "./Admin.module.css";

import AdminNavigation from "./AdminNavigation";

const Admin = () => {
  return (
    <>
     <AdminNavigation></AdminNavigation>
      <main className={classes.main}></main>
    </>
  );
};

export default Admin;
