package com.project2.project2.controller;

import com.project2.project2.Beans.Category;
import com.project2.project2.Beans.Coupon;
import com.project2.project2.Beans.UserDetails;
import com.project2.project2.Exceptions.CompanyUserException;
import com.project2.project2.Exceptions.CouponException;
import com.project2.project2.Exceptions.CustomerUserException;
import com.project2.project2.Exceptions.LoginException;
import com.project2.project2.Login.ClientType;
import com.project2.project2.Login.LoginManager;
import com.project2.project2.Service.CompanyService;
import com.project2.project2.Service.CustomerService;
import com.project2.project2.Util.JWTutil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 *
 * This class is in charge of all the VERBS that we use with our external servers.
 * It has 6 VERBS of type POST to add/update/delete/get coupons.
 * It is in charge of handling REST API requests and returning the response.
 *
 */
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RestController
@RequestMapping("/Customer")
@RequiredArgsConstructor
public class CustomerController {
    private  CustomerService customerService;
    private final LoginManager loginManager;
    private final JWTutil jwTutil;


    @PostMapping("/login")
    @ResponseStatus(HttpStatus.OK)
    private ResponseEntity<?>login(@RequestBody UserDetails userDetails /*(HttpServletResponse response*/) throws LoginException {
        try {
            customerService = (CustomerService) loginManager.login(userDetails.getUserEmail(), userDetails.getUserPassword(), userDetails.getClientType());
            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.set("Authorization",jwTutil.generateToken(userDetails));
//            Cookie cookie = new Cookie("token",jwTutil.generateToken(userDetails));
//            cookie.setMaxAge(60*30);
//            cookie.setPath("/");
//            response.addCookie(cookie);
          
            return ResponseEntity.ok().headers(responseHeaders).body("Welcome customer"+customerService.getCustomerDetails().getFirstName());

        } catch (CompanyUserException | CustomerUserException |NullPointerException e) {
            throw new LoginException("incorrect details");
        }
    }

    private HttpHeaders getHeaders(String token) {
        UserDetails userDetails = new UserDetails();
        userDetails.setUserEmail(jwTutil.extractEmail(token));
        System.out.println(jwTutil.extractAllClaims(token).get("clientType"));
        userDetails.setClientType(ClientType.valueOf((String) jwTutil.extractAllClaims(token).get("clientType")));
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Authorization", jwTutil.generateToken(userDetails));
        return httpHeaders;

    }
    /**
     * This verb enable the customer to purchase coupons  from external server.
     *
     * @param couponID of the coupon that the customer purchased.
     * @return ResponseEntity<> with message and HTTP status.
     *
     * @throws CouponException
     */
    @PostMapping("/purchaseCoupon/{couponID}")
    private ResponseEntity<?>purchaseCoupon(@RequestHeader(name="Authorization")String token,@PathVariable long couponID) throws CouponException {
        if(jwTutil.validateToken(token)) {
            try {
                customerService.purchaseCoupon(couponID);
               return ResponseEntity.ok().headers(getHeaders(token)).body("Coupon " + couponID + " purchased");
            } catch (CouponException e) {
                throw new CouponException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }
    @PostMapping("/purchaseCoupons")
    private ResponseEntity<?>purchaseCouponList(@RequestHeader(name="Authorization")String token, @RequestBody List<Coupon>coupons) throws CouponException {
        if(jwTutil.validateToken(token)) {
            try {
                customerService.purchaseCouponList(coupons);
                return ResponseEntity.ok().headers(getHeaders(token)).body("Coupons has been purchased");
            } catch (CouponException e) {
                throw new CouponException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the customer to delete coupon  from external server.
     *
     * @param couponId of the coupon we deleting.
     * @return ResponseEntity<> with message and HTTP status.
     * @throws CouponException
     */
    @PostMapping("/removeCoupon/{couponId}")
    private ResponseEntity<?>removeCoupon(@RequestHeader(name = "Authorization")String token,@PathVariable long couponId) throws CouponException {
        if(jwTutil.validateToken(token)) {
            try {
                customerService.removeCoupon(couponId);
                return ResponseEntity.ok().headers(getHeaders(token)).body("Coupon"+couponId+"has been deleted");
            } catch (CouponException e) {
                throw new CouponException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the customer to get all coupons by category from the system from external server.
     * @param category of the coupon
     * @return ResponseEntity<> with list of all coupons and HTTP status.
     * @throws CustomerUserException
     */
    @PostMapping("/getCustomerCouponsByCategory/{category}")
    private ResponseEntity<?>getCustomerCouponsByCategory(@RequestHeader(name="Authorization")String token,@PathVariable Category category) throws CustomerUserException {
        if(jwTutil.validateToken(token)) {
            try {
                return ResponseEntity.ok().headers(getHeaders(token)).body(customerService.getCustomerCouponsByCategory(category));
            } catch (CustomerUserException e) {
                throw new CustomerUserException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the customer to get all coupons that were purchased from external server.
     *
     * @return ResponseEntity<> with list of all purchased coupons and HTTP status.
     * @throws CustomerUserException
     */
    @PostMapping("/getAllPurchasedCoupons")
    private ResponseEntity<?>getAllPurchasedCoupons(@RequestHeader(name = "Authorization")String token) throws CustomerUserException {
        if(jwTutil.validateToken(token)) {
            try {
                return ResponseEntity.ok().headers(getHeaders(token)).body(customerService.getAllPurchasedCoupons());
            } catch (CustomerUserException e) {
                throw new CustomerUserException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the customer to get all coupons by max price of the coupon from the system from external server.
     * @param maxPrice of the coupon
     * @return ResponseEntity<> with list of all coupons with max price and HTTP status.
     * @throws CustomerUserException
     */
    @PostMapping("/getCustomerCouponsByMaxPrice/{maxPrice}")
    private ResponseEntity<?>getCustomerCouponsByMaxPrice(@RequestHeader(name = "Authorization")String token,@PathVariable double maxPrice) throws CustomerUserException {
        if(jwTutil.validateToken(token)) {
            try {
                return ResponseEntity.ok().headers(getHeaders(token)).body(customerService.getCustomerCouponsByMaxPrice(maxPrice));
            } catch (CustomerUserException e) {
                throw new CustomerUserException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the customer to get all customer details from external server.
     *
     * @return ResponseEntity<> with list of all customer details and HTTP status.
     *
     */
    @PostMapping("/CustomerDetails")
    private ResponseEntity<?>getCustomerDetails(@RequestHeader(name = "Authorization")String token){
        if(jwTutil.validateToken(token)) {
            return ResponseEntity.ok().headers(getHeaders(token)).body(customerService.getCustomerDetails());
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

}
