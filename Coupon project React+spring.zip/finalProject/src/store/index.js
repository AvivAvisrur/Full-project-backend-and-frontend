import cartSlice from './cart-slice';
import { configureStore } from '@reduxjs/toolkit';
import authSlice from './auth-slice';

const store = configureStore({
    reducer:{cart: cartSlice.reducer,auth:authSlice.reducer},
});

export default store;