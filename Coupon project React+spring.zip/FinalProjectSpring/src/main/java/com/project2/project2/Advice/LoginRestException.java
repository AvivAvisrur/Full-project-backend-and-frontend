package com.project2.project2.Advice;

import com.project2.project2.Exceptions.LoginException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * This class is in charge of intercepting our login errors.
 * has 1 method for the exception that can be thrown from the system.
 */

@RestController
@ControllerAdvice
public class LoginRestException {
    /**
     * This method allow the system to intercept errors regarding login.
     *
     * @param e the exception we are intercepting.
     * @return errorDetail object
     *
     */
    @ExceptionHandler(value = {LoginException.class})
    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    public ErrorDetail handleLoginError(Exception e){
        return new ErrorDetail("Login error",e.getMessage());
    }
}
