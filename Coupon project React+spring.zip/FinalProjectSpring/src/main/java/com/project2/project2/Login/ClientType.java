package com.project2.project2.Login;

/**
 * This is enum class use to navigate between login access of the users.
 */

public enum ClientType {
    administrator,company,customer
}
