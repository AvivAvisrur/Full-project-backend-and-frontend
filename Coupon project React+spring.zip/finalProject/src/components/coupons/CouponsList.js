

import CouponItem from "./CouponItem";
import classes from "./CouponsList.module.css";

const CouponsList = (props) => {
  console.log(props);
  return (
    <div  className={classes.coupons}>
      {props.coupons.map((coupon) => (
        <CouponItem
           key = {coupon.id}
          image={coupon.image}
          id={coupon.id}
          title={coupon.title}
          description={coupon.description}
          price={coupon.price}
          amount ={coupon.amount}
          category ={coupon.category}
          companyID = {coupon.companyId}
          startDate = {coupon.startDate}
          endDate = {coupon.endDate}
          

        />
      ))}
    </div>
  );
};

export default CouponsList;
