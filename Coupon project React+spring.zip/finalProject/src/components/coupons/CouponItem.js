import Card from "../UI/Card";
import classes from "./CouponItem.module.css";
import { useDispatch } from "react-redux";
import { cartActions } from "../../store/cart-slice";


const CouponItem = (props) => {
  const dispatch = useDispatch();

  const { title, price, description, image, id } = props;

  const addToCartHandler = () => {
    dispatch(
      cartActions.addItemToCart({
        id,
        title,
        price,
        image,
        description,
      })
    );
  };

  return (
    <Card>
      <div className={classes.coupon} key={props.id}>
        <img alt={"img"} src={props.image} />
        <div className={classes.CouponItemInfo}>
          <h3>{props.title}</h3>
          <div className={classes.description}>{props.description}</div>
          <div className={classes.CouponItemPriceInfo}>
            <button onClick={addToCartHandler}>Order</button>
            <div className={classes.value}></div>
            <div className={classes.price}>{price}$</div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default CouponItem;
