import IconButton from "./buttons/IconButton";
import classes from "./Header.module.css";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import "bootstrap/dist/css/bootstrap.css";
import MainNavigation from "./MainNavigation";
import { useState } from "react";
import { useSelector } from "react-redux";
import Card from "../UI/Card";
import CartItem from "./buttons/CartItem";
import axios from "axios"

const Header = () => {
  const cartQuantity = useSelector((state) => state.cart.totalQuantity);
  const cartTotalprice = useSelector((state) => state.cart.totalPrice);
  const cartItems = useSelector((state) => state.cart.items);
  const token = useSelector(state=>state.auth.token);
//this method down here purchase the coupons from the cart.
  

  const buyCouponsHandler = ()=>{
    cartItems.map(item=>{
      let id = item.id;
      console.log(id)
      axios.post(`http://localhost:8081/Customer/purchaseCoupon/${id}`,id,{headers:{"Authorization":token }}).then(response=>{
        console.log(response.headers)
    }).catch(error=>{
        console.log(error);
    })
    })
    

  }
  const [showShoppingCard, setShowShoppingCart] = useState(false);
  const renderShoppingCart = () => {
    return (
      <Card className={classes.shoppingCartContainer}>
        <ul>
          {cartItems.map((item) => (
            <CartItem
              key={item.id}
              item={{
                id: item.id,
                title: item.name,
                quantity: item.quantity,
                total: item.totalPrice,
                price: item.price,
                image: item.image,
              }}
            />
          ))}
        </ul>
        {cartTotalprice > 0 ? (
          <>
            <div className={classes.TotalAmount}>
              Total Amount {cartQuantity}
            </div>
            <div className={classes.TotalPrice}>
              Total price {cartTotalprice.toFixed(2)}
            </div>
            <button onClick = {buyCouponsHandler} className={classes.Buy}>Buy</button>
          </>
        ) : <p className={classes.Par}>Your Cart Is Empty!</p>}
      </Card>
    );
  };
  return (
    <header>
      <div className={classes.header}>
        <h1>Coupons World</h1>

        <div className={classes.buttons}>
          {showShoppingCard ? renderShoppingCart() : null}
          <IconButton
            onClick={() => {
              setShowShoppingCart(!showShoppingCard);
            }}
          >
            <div className={classes.shoppingCartInfo}>
              <ShoppingCartIcon color="secondary" sx={{ color: "white" }} />
              <div className={classes.shoppingCartAmount}>{cartQuantity}</div>
            </div>
          </IconButton>
          <MainNavigation />
        </div>
      </div>
    </header>
  );
};

export default Header;
