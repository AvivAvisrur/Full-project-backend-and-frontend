import { useState } from "react";
import ContactUs from "./contact-us";
import Button from "../Header/buttons/Button";
import classes from "./AboutUs.module.css";


const AboutUs = () => {
  const [isClicked, setIsClicked] = useState(false);


  const renderLogin = () => {
    return (
      <div>
        <ContactUs />
      </div>
    );
  };

  return (
    <div className ={classes.aboutUs}>
      <h1>Who Are We?</h1>
      <p className={classes.Par}>
        We provide coupons sale to customers from many types.
        <br /> Such as: Food, Electricity, Hotels and more...<br/>We also provide the aportunity to companies to sale theirs coupons.

      </p>
      {isClicked ? renderLogin() : null}
      {!isClicked ? <Button
        className={classes.Button}
        onClick={() => setIsClicked(!isClicked)}
      >
        Contact Us
      </Button> : <Button className={classes.Button} onClick={() => setIsClicked(!isClicked)}>Cancel</Button>}
    </div>
  );
};
export default AboutUs;
