import InputForm from "../../Forms/InputForm"

const UpdateCompany = ()=>{
    return <InputForm type = "Company" isUpdate={true} url = "http://localhost:8081/Admin/updateCompany" />
}
export default UpdateCompany;