import InputForm from "../../Forms/InputForm"
const AddCompany = ()=>{
 return <InputForm type = "Company" isUpdate={false} url ="http://localhost:8081/Admin/addCompany"/>
}
export default AddCompany;