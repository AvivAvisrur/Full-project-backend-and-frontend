import DeleteForm from "../../Forms/DeleteForm";

const DeleteCustomer = ()=>{
    return <DeleteForm type="Customer" url = "http://localhost:8081/Admin/deleteCustomer/"/>
};
export default DeleteCustomer;