package com.project2.project2.Advice;

import com.project2.project2.Exceptions.CompanyUserException;
import com.project2.project2.Exceptions.CustomerUserException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * This class is in charge of intercepting our Admin errors.
 * has 2 methods for each exception that can be thrown from the system.
 */

@RestController
@ControllerAdvice
public class AdminRestException {

    /**
     * This method allow the system to intercept errors regarding company.
     *
     * @param e the exception we are intercepting.
     * @return ErrorDetail object
     *
     */
    @ExceptionHandler(value = {CompanyUserException.class})
    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    public ErrorDetail handleCompanyException(Exception e){
        return new ErrorDetail("Company Error",e.getMessage());
    }


    /**
     * This method allow the system to intercept errors regarding customer.
     *
     * @param e the exception we are intercepting.
     * @return ErrorDetail object
     */
    @ExceptionHandler(value = {CustomerUserException.class})
    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    public ErrorDetail handleCustomerException(Exception e){
        return new ErrorDetail("Customer Error",e.getMessage());
    }
}
