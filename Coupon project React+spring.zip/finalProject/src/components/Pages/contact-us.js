import classes from "./contact-us.module.css";
import FacebookRoundedIcon from '@mui/icons-material/FacebookRounded';




const ContactUs = () => {
  return (
    <>
      <h1>Aviv Avisror</h1>
      <div className={classes.Phone}>Phone: 050-744-5456</div>
      <div className={classes.Email}>Email: Aviv4588@gmail.com</div>
      <div className={classes.Link}>
      <a href="https://www.facebook.com/aviv.avisrur.3" target="_blank" rel="noreferrer noopener">
      FaceBook
</a>
</div>
      <h1>Rachel Lugassi</h1>
      <div className={classes.Phone}>Phone: 054-791-1049</div>
      <div className={classes.Email}>Email: srachelu@gmail.com</div>
      <div className={classes.Link}>
      <a className = {`${classes.fa} ${classes.faFacebook}`} href="https://www.facebook.com/rachel.lugassi.9" target="_blank" rel="noreferrer noopener">
   FaceBook
</a>


      </div>
      
    </>
  );
};

export default ContactUs;
