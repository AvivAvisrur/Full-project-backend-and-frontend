import Logout from "../Logout";
import classes from "./CustomerHeader.module.css";
import { Link } from "react-router-dom";


const CustomerHeader = () => {
  return (
    <>
      <div className={classes.header}>
        <h1>Customer Page</h1>
        <Logout />
        <Link to="/myCoupons">Your orders</Link>
      </div>
    </>
  );
};

export default CustomerHeader;