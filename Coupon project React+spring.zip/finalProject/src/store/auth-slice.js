import { createSlice } from "@reduxjs/toolkit";
import jwtDecode from "jwt-decode";

const getInitialstate = ()=>{
    //const token = localStorage.getItem("token");
    var token = localStorage.getItem("token");
    if(token){
        const loadState = {
            token : token,
            clientType : jwtDecode(token).clientType,
            isLoggedIn : true
        }
        return loadState
    }
    const loadState = {
        token:"",
        clientType:"",
        isLoggedIn:false
    }
    return loadState;
}
const authSlice = createSlice(
    {
    name:"auth",
    initialState:getInitialstate(),
    reducers:{
        login(state,action){
           
            state.token = action.payload;
            state.clientType = jwtDecode(state.token).clientType;
            state.isLoggedIn = true;
            localStorage.setItem("token",state.token);
        },
        logout(state){
            state.isLogged = false;
            state.token = "";
            state.clientType = "";
            localStorage.removeItem("token");
        }
    }
}
);
export const authActions = authSlice.actions;
export default authSlice;

