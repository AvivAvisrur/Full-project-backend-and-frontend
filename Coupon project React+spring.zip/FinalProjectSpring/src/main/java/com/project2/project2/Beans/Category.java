package com.project2.project2.Beans;

/**
 * Enum class for the category types of the coupons.
 */
public enum Category {
    Food, Electricity, Restaurant, Vacation;
}
