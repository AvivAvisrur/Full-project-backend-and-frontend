package com.project2.project2.Exceptions;

public class LoginException  extends Exception{
    public LoginException() {
    }

    public LoginException(String message) {
        super(message);
    }
}
