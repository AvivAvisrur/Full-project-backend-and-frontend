import axios from "axios";
import { useRef } from "react";
import { useSelector } from "react-redux";
import Card from "../../UI/Card"
import classes from "./SignUp.module.css"
const SignUp = ()=>{
    const token = useSelector(state=>state.auth.token);
    const emailInputRef = useRef()
    const passwordInputRef = useRef()
    const firstNameInputRef = useRef();
    const lastNameInputRef = useRef()
    console.log(token)

    const submitHandler = (event)=>{
        event.preventDefault();
        const userDetails = {
            firstName:firstNameInputRef.current.value,
            lastName :lastNameInputRef.current.value,
            email:emailInputRef.current.value,
            password:passwordInputRef.current.value 
        }

        
    axios.post("http://localhost:8081/Guest/addCustomer",userDetails).then(response=>{
        console.log(response.headers)
    }).catch(error=>{
        console.log(error);
    })
}


    return <Card className = {`${classes.form} ${classes.signUp} `}>
    <form onSubmit = {submitHandler}  >
        <h3>Register</h3>

        <div className={classes.control}>
            <label>First name</label>
            <input type="text" className="form-control" placeholder="First name" ref={firstNameInputRef} />
        </div>

        <div className={classes.control}>
            <label>Last name</label>
            <input type="text" className="form-control" placeholder="Last name" ref={lastNameInputRef}/>
        </div>

        <div className={classes.control}>
            <label>Email</label>
            <input type="email" className="form-control" placeholder="Enter email" ref={emailInputRef} />
        </div>

        <div className={classes.control}>
            <label>Password</label>
            <input type="password" className="form-control" placeholder="Enter password" ref = {passwordInputRef} />
        </div>

        <button type="submit" className="btn btn-dark btn-lg btn-block">Register</button>
        <p className="forgot-password text-right">
            Already registered? <a href = "/">Log in</a>
        </p>
    </form>
    </Card>
};
export default SignUp;