package com.project2.project2.Configs;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;

/**
 * This class allow us the connection to external servers. and setting timeout for this connection.
 *
 */

@Configuration
public class MyRestTemplate {

    /**
     * This method creates us an  object of RestTemplate which will set the timeout for the connection.
     * @param builder
     * @return builder an object of RestTemplate type.
     */
    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder
                //set connection time out for 3 sec
                .setConnectTimeout(Duration.ofMillis(3000))
                //set read time out for 3 sec.
                .setReadTimeout(Duration.ofMillis(3000))
                .build();
    }
}
