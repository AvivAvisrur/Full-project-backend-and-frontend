import InputForm from "../../Forms/InputForm"

const UpdateCustomer = ()=>{
    return <InputForm type = "Customer" isUpdate = {true} url = {"http://localhost:8081/Admin/updateCustomer"} />
};
export default UpdateCustomer