import "./index.css";
import Layout from "./components/mainLayout/Layout";
import { Switch, Route } from "react-router";
import HomePage from "./components/Pages/HomePage";
import Login from "./components/Header/Login/Login";
import SignUpPage from "./components/Pages/SignUpPage";
import AboutUs from "./components/Pages/AboutUs";
import Managment from "./components/Pages/Admin/Managment";
import AddCompany from "./components/Pages/Admin/methods/AddCompany";
import UpdateCompany from "./components/Pages/Admin/methods/UpdateCompany";
import DeleteCompany from "./components/Pages/Admin/methods/DeleteCompany";
import UpdateCustomer from "./components/Pages/Admin/methods/UpdateCustomer";
import DeleteCustomer from "./components/Pages/Admin/methods/DeleteCustomer";

const App = () => {
  return (
    <Layout>
      <Switch>
        <Route path="/home">
          <HomePage />
        </Route>
        <Route path="/login">
          <Login />
        </Route>
        <Route path="/sign-up">
          <SignUpPage />
        </Route>
        <Route path="/about-us">
          <AboutUs />
        </Route>
        <Route path="/managment">
         <Managment/>
        </Route>
        <Route path="/addCompany">
          <AddCompany/>
        </Route>
        <Route path = "/updateCompany">
          <UpdateCompany/>
        </Route>
        <Route path = "/deleteCompany">
        <DeleteCompany/>
        </Route>
        <Route path = "/updateCustomer">
          <UpdateCustomer/>
        </Route>
        <Route path = "/deleteCustomer">
          <DeleteCustomer/>
        </Route>
      </Switch>
    </Layout>
  );
};

export default App;
