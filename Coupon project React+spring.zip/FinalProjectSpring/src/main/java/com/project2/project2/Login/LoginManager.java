package com.project2.project2.Login;


import com.project2.project2.Configs.ServiceaConfiguration;
import com.project2.project2.Exceptions.CompanyUserException;
import com.project2.project2.Exceptions.CustomerUserException;

import com.project2.project2.Exceptions.LoginException;
import com.project2.project2.Service.AdminService;
import com.project2.project2.Service.ClientService;
import com.project2.project2.Service.CompanyService;
import com.project2.project2.Service.CustomerService;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

/**
 * This class is responsible of the management of the login process when you enter
 * email and pass it will navigate you to the specific facade u logged in.
 *
 * This class has 1 attribute from Logic manager . because it is a singleton the instance should be null first.
 */


@Service
@RequiredArgsConstructor
public class LoginManager {

    private final ServiceaConfiguration config;

    /**
     * This method is in charge of the login of the client to the system.
     * @param email is the email of the client. who tries to login to the system.
     * @param password is the password of the client.
     * @param clientType is the type of the client: admin/company/customer.
     * @return access to all the authorized method of the client if exists if not returns null.
     * @throws CompanyUserException
     * @throws CustomerUserException
     *
     */
    public ClientService login(String email, String password, ClientType clientType) throws CompanyUserException, CustomerUserException, LoginException {
        switch (clientType) {
            case company:
                CompanyService cf = config.initilaizeCompanyService();
                return cf.login(email, password) ? cf : null;
            case administrator:
                AdminService af = config.initilaizeAdminService();
                return af.login(email, password) ? af : null;
            case customer:
                CustomerService cuf =  config.initilaizeCustomerService();
                return cuf.login(email, password) ? cuf : null;
            default:
                return null;
        }
    }
}
