import { useState } from "react";

import Card from "../../UI/Card"
import classes from "./SignUp.module.css"
import axios from "axios";
import { useSelector } from "react-redux";
import jwtAxios from "../../jwt/jwtAxios";
const DeleteForm = (props)=>{
    const [id,setIdInput] = useState(0);

const idInputHandler = (event)=>{
    setIdInput(event.target.value);
}
const onSubmitHandler = (event)=>{
    event.preventDefault();
    jwtAxios.post(`${props.url}${id}`,id)
    .then(response=>{
        console.log(response.headers)
    })
    .catch(error=>{
        console.log(error);
    })


}
return (
    <Card className = {`${classes.form} ${classes.signUp} `}>
        <form onSubmit={onSubmitHandler}>
        <h3>{`Delete ${props.type}`}</h3>
        <div className={classes.control}>
            <label> {props.type} ID</label>
            <input onChange = {idInputHandler} value = {id} type="number" className="form-control" placeholder={`${props.type} ID`}/>
        </div>
        <button type="submit" className="btn btn-dark btn-lg btn-block">Delete</button>
        </form>
    </Card>
)
}
export default DeleteForm;