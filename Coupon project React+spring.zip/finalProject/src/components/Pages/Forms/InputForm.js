
import axios from "axios";
import { useRef } from "react";
import { useSelector } from "react-redux";
import Card from "../../UI/Card"
import classes from "./SignUp.module.css"
import jwtAxios from "../../jwt/jwtAxios"

const UpdateForm = (props)=>{
    const emailInputRef = useRef()
    const passwordInputRef = useRef()
    const NameInputRef = useRef();
    const firstNameRef = useRef();
    const lastNameRef = useRef();
    const idInputRef = useRef();
    const token = useSelector(state=>state.auth.token);
    const url = props.url
    //const [userDetails,setUserDetails] = useState({})

    const updateSubmitHandler = (event)=>{
        event.preventDefault();
        if(props.type ==="Customer"){
             const userDetails ={
                email:emailInputRef.current.value,
                firstName:firstNameRef.current.value,
                id:idInputRef.current.value,
                lastName:lastNameRef.current.value,
                password:passwordInputRef.current.value 
            }
            jwtAxios.post(url,userDetails).then(response=>{
                console.log(response.headers)
            }).catch(error=>{
                console.log(error);
            })
            console.log(userDetails)
        }else{
         const userDetails = {
            id:idInputRef.current.value,
            email:emailInputRef.current.value,
            password:passwordInputRef.current.value 
        }
        jwtAxios.post(url,userDetails).then(response=>{
            console.log(response.headers)
        }).catch(error=>{
            console.log(error);
        })
    }
}

    const submitHandler = (event)=>{
        event.preventDefault();
        const userDetails = {
            email:emailInputRef.current.value,
           name:NameInputRef.current.value,
            password:passwordInputRef.current.value 
        }
        console.log(userDetails)

    jwtAxios.post(url,userDetails).then(response=>{
        console.log("zeev");
    }).catch(error=>{
        console.log(error);
    })
}


    return <Card className = {`${classes.form} ${classes.signUp} `}>
    <form onSubmit = {props.isUpdate?updateSubmitHandler:submitHandler}  >
        <h3>{props.isUpdate?`Update ${props.type}`:`Add ${props.type}`}</h3>
        {props.isUpdate&&
        <div className={classes.control}>
            <label> {props.type} ID</label>
            <input type="number" className="form-control" placeholder={`${props.type} ID`} ref={idInputRef} />
        </div>}

        {props.type==="Customer"&&
        <div className={classes.control}>
            <label> {props.type} First Name</label>
            <input type="text" className="form-control" placeholder="First Name" ref={firstNameRef} />
        </div>}

        
        {props.type==="Customer"&&
        <div className={classes.control}>
            <label> {props.type} Last Name</label>
            <input type="text" className="form-control" placeholder="Last Name" ref={lastNameRef} />
        </div>}

        {!props.isUpdate&&<div className={classes.control}>
            <label> {props.type} name</label>
            <input type="text" className="form-control" placeholder={`${props.type} name`} ref={NameInputRef} />
        </div>}
        

        <div className={classes.control}>
            <label>Email</label>
            <input type="email" className="form-control" placeholder="Enter email" ref={emailInputRef} />
        </div>

        <div className={classes.control}>
            <label>Password</label>
            <input type="password" className="form-control" placeholder="Enter password" ref = {passwordInputRef} />
        </div>

        <button type="submit" className="btn btn-dark btn-lg btn-block">{props.isUpdate?"Update":"Add"}</button>
    </form>
    </Card>
};
export default UpdateForm;