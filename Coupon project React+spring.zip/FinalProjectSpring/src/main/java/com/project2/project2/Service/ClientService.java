package com.project2.project2.Service;

import com.project2.project2.Exceptions.CompanyUserException;
import com.project2.project2.Exceptions.CustomerUserException;
import com.project2.project2.Exceptions.LoginException;
import com.project2.project2.Repositories.CompanyRepo;
import com.project2.project2.Repositories.CouponRepo;
import com.project2.project2.Repositories.CustomerRepo;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * This class is an abstract class of all the service class in the system.
 *
 * This class has 3 attributes of Repo's to give us access to the methods in the service.
 */

public abstract class ClientService {
    @Autowired
    protected CustomerRepo customerRepo;
    @Autowired
    protected CouponRepo couponRepo;
    @Autowired
    protected CompanyRepo companyRepo;

    /**
     * This is abstact method we will implements in the child classes .
     * @param email email of the user that try to log in
     * @param password the password of the user that try to log in
     * @throws CompanyUserException
     * @throws CustomerUserException
     */
    public abstract boolean login (String email, String password) throws CompanyUserException, CustomerUserException, LoginException;

}
