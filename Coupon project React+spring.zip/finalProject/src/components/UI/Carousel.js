import {useState} from "react";
import {Carousel} from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.css";

function CarouselHeader() {
    const [index, setIndex] = useState(0);
  
    const handleSelect = (selectedIndex, e) => {
      setIndex(selectedIndex);
    };
  
    return (
      <Carousel variant = "dark"  activeIndex={index} onSelect={handleSelect}>
        <Carousel.Item>
          <img
            className="d-block w-100 images"
            src="https://www.just4u.co.il/Pictures/188918646.jpg"
            alt="First slide"
          />
          <Carousel.Caption>
            <h3>מגש סושי ברשת ג׳פניקה</h3>
            <p>רק ב250 ש״ח 96 חתיכות סושי מובחרים וטעימים</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100 images"
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8OtYQJ5_axuBrRBzC5ewQzsmXEvNdWZuElQ&usqp=CAU"
            alt="Second slide"
          />
  
          <Carousel.Caption>
            <h3>פיצה ברשת דומינוס</h3>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100 images"
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIP0SCu-9CRAfQg1Xu6ZZzPBsp4H60sRaRxA&usqp=CAU"
            alt="Third slide"
          />
  
          <Carousel.Caption>
            <h3>Hamburger coupon</h3>
            <p>
              10% on hamburger.
            </p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
    );
  }
  export default CarouselHeader;
