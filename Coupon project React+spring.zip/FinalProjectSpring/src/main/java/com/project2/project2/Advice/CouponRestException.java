package com.project2.project2.Advice;

import com.project2.project2.Exceptions.CompanyUserException;
import com.project2.project2.Exceptions.CouponException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * This class is in charge of intercepting our coupons errors.
 * has 1 method for the exception that can be thrown from the system.
 */

@RestController
@ControllerAdvice
public class CouponRestException {

    /**
     * This method allow the system to intercept errors regarding coupon.
     *
     * @param e the exception we are intercepting.
     * @return errorDetail object
     *
     */
    @ExceptionHandler(value = {CouponException.class})
    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    public ErrorDetail handleCouponException(Exception e){
        return new ErrorDetail("Coupon error",e.getMessage());
    }

}
