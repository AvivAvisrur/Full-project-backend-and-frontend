import CouponsList from "../coupons/CouponsList";
import "./Homepage.module.css"
import axios from "axios";
import {useState,useEffect} from "react"


  
const HomePage = ()=>{
    const [coupons, setCoupons] = useState([]);
    useEffect(() => {
      axios.post("http://localhost:8081/Guest/getAllCoupons")
        .then((response) => {
          setCoupons(response.data)
          console.log(response.data)
        })
        .catch((error) => {
          console.log(error);
        })
    }, [])
  
    return <CouponsList coupons = {coupons}/>
};
export default  HomePage;
