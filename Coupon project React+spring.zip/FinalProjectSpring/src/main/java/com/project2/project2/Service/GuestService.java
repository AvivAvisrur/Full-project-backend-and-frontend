package com.project2.project2.Service;

import com.project2.project2.Beans.Coupon;
import com.project2.project2.Beans.Customer;
import com.project2.project2.Exceptions.CustomerUserException;
import com.project2.project2.Repositories.CouponRepo;
import com.project2.project2.Repositories.CustomerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 * This class has 1 attributes from type couponRepo.
 * has 1 method that returns list of all the coupons exists in the system.
 */

@Service
public class GuestService {
    @Autowired
    private CouponRepo couponRepo;
    @Autowired
    private CustomerRepo customerRepo;

    /**
     * @return all the coupons in the system.
     */
    public List<Coupon>getAllCoupons(){
        return couponRepo.findAll();
    }
    public void addCustomer(Customer customer) throws CustomerUserException {
        try {
            customerRepo.save(customer);
            System.out.println("Customer added successfully ");
        }catch (DataIntegrityViolationException e){
            throw new CustomerUserException("User already exists!");
        }
    }
}
