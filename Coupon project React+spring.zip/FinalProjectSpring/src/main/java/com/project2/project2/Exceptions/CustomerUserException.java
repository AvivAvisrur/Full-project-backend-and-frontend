package com.project2.project2.Exceptions;

public class CustomerUserException extends Exception {
    public CustomerUserException() {
    }
    public CustomerUserException(String message) {
        super((message));
    }
}
