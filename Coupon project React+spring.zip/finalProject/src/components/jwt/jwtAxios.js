import axios from "axios";
import store from "../../store";
import { authActions } from "../../store/auth-slice";
const jwtAxios = axios.create();

//request interceptor -> when sending request to server (from react to spring)
//in the request we will send the jwt token
jwtAxios.interceptors.request.use(request=>{
    request.headers = {
        //get the current token from redux
        "Authorization" : store.getState().auth.token,
    }
    return request;
    
});

//response interceptor -> when getting data from the server (from spring to react)
jwtAxios.interceptors.response.use(response=>{
    console.log("inside interceptors");
    console.log(response.headers.authorization);
    //save in redux (memory of application, works only if browser still open)
    store.dispatch(authActions.login(response.headers.authorization));
    //save as coockie, works even if you reopen the browser
    localStorage.setItem("token",response.headers.authorization);
});
export default jwtAxios;                                    