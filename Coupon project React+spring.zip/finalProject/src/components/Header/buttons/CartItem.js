import classes from "./CartItem.module.css";
import { useDispatch } from "react-redux";
import { cartActions } from "../../../store/cart-slice";

const CartItem = (props) => {
  const dispatch = useDispatch();

  const { title, quantity, total, price, id, image} = props.item;

  const removeItemHandler = () => {
    dispatch(cartActions.removeItemFromCart(id));
  };

  const addItemHandler = () => {
    dispatch(
      cartActions.addItemToCart({
        id,
        title,
        price,
      })
    );
  };

  return (
    <li className={classes.Item}>
      <img alt = "" src={image} />
      <div className={classes.CartItemInfo}>
        <h3>{title}</h3>
        <div className={classes.Details}>
          <div className={classes.Quantity}>
            x <span>{quantity}</span>
          </div>
          <div className={classes.Actions}>
            <button onClick={removeItemHandler}><span>-</span></button>
            <button onClick={addItemHandler}><span>+</span></button>
          </div>
        </div>
        <div className={classes.Separator}></div>
        <div className={classes.Price}>
          <span className={classes.PriceTitle}>Price:</span>
          <span>${total.toFixed(2)}{` (${price.toFixed(2)}/item)`}</span>
        </div>
      </div>
    </li>
  );
};

export default CartItem;
