package com.project2.project2.Service;

import com.project2.project2.Beans.Category;
import com.project2.project2.Beans.Coupon;
import com.project2.project2.Beans.Customer;
import com.project2.project2.Exceptions.CouponException;
import com.project2.project2.Exceptions.CustomerUserException;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This class extends another abstract class.
 * This class has methods that unable customer to login the system of purchasing coupons from few different types,
 * buying coupons, and getting coupons.
 *
 * This class has 1 attribute from type int. which represents the id number of the customer who can buy coupon
 */

@Service
public class CustomerService extends ClientService {
    private long customerId;


  /**
   * This method enable login of customer to the system.
   *
   * @param email    of the customer who tries to login.
   * @param password of the customer who tries to login.
   * @return boolean value. true if the customer succeed to login and false if he could not.
   */
  @Override
    public boolean login(String email, String password)  {
    try {
      customerId = customerRepo.findByEmailAndPassword(email, password).getId();
      System.out.println("Login successful");
      return true;
    }catch (NullPointerException e){
      System.out.println("Customer is not exists!");
    }
    return false;
    }

  /**
   * This method unable the customer to buy coupon unless he bought the same coupon already.
   *
   * @param couponID of the customer.
   * @throws CouponException Exceptions relating to the validity of the coupon fields or purchase restrictions
   *
   */
    public void purchaseCoupon(long couponID) throws CouponException {
    Coupon coupon = couponRepo.findById(couponID);
    if(!couponRepo.existsById(couponID)){
      throw new CouponException("Unable to purchase Coupon is not exists!");
    }
      if(coupon.getAmount()<1){
        throw new CouponException("Coupon is out of stock!");
      }
      if(coupon.getEndDate().before(new java.sql.Date(System.currentTimeMillis()))){
        throw new CouponException("Coupon has expired!");
      }
      Customer updateCustomer = customerRepo.findById(customerId);
      updateCustomer.getCoupons().add(coupon);
      coupon.setAmount(coupon.getAmount()-1);
      couponRepo.saveAndFlush(coupon);
      customerRepo.saveAndFlush(updateCustomer);
    }
  public void purchaseCouponList(List<Coupon> coupons) throws CouponException {
    System.out.println(coupons);
    for (Coupon item : coupons) {
      if (!couponRepo.existsById(item.getId())) {
        throw new CouponException("Unable to purchase Coupon is not exists!");
      }
      if (item.getAmount() < 1) {
        throw new CouponException("Coupon is out of stock!");
      }
      if (item.getEndDate().before(new java.sql.Date(System.currentTimeMillis()))) {
        throw new CouponException("Coupon has expired!");
      }
      item.setAmount(item.getAmount() - 1);
      couponRepo.saveAndFlush(item);

    }
    Customer updateCustomer = customerRepo.findById(customerId);
    updateCustomer.setCoupons(coupons);
    customerRepo.saveAndFlush(updateCustomer);
  }


  /**
   * This method allow the  to delete coupon  from the system.
   *
   * @param couponId of the customer.
   * @throws CouponException
   */
    public void removeCoupon(long couponId) throws CouponException {
      if(!customerRepo.findById(customerId).getCoupons().contains(couponRepo.findById(couponId))){
        throw new CouponException("Delete unsuccessful coupon does not exists!");
      }
      Coupon coupon = couponRepo.findById(couponId);
      Customer updateCustomer = customerRepo.findById(customerId);
      int index = updateCustomer.getCoupons().indexOf(coupon);
      updateCustomer.getCoupons().remove(index);
      coupon.setAmount(coupon.getAmount()+1);
      couponRepo.saveAndFlush(coupon);
      customerRepo.saveAndFlush(updateCustomer);


    }

  /**
   * This is a getter method by customer id and coupons category.
   * @param category of client type
   * @return ArrayList of all the coupons that 1 customer bought by customer id number and category of the coupon.
   * @throws CustomerUserException
   */
    public List<Coupon> getCustomerCouponsByCategory(Category category) throws CustomerUserException {
      if(couponRepo.findCutomersCouponByCategory(customerId,category.ordinal()).isEmpty()){
        throw new CustomerUserException("This customer dont have coupons in this category");
      }
      return couponRepo.findCutomersCouponByCategory(customerId,category.ordinal());
    }

  /**
   * This is a getter method by customer id.
   *
   * @return ArrayList of all the coupons that 1 customer bought by customer id number.
   * @throws CustomerUserException
   */
    public List<Coupon> getAllPurchasedCoupons() throws CustomerUserException {
      if(customerRepo.findById(customerId).getCoupons().isEmpty()){
        throw new CustomerUserException("This customer has no coupons");
      }
        return customerRepo.findById(customerId).getCoupons();
    }

  /**
   * This is a getter method by customer id and coupons max price.
   * @param maxPrice of the coupons
   * @return ArrayList of all the coupons that 1 customer bought by customer id number and max price of the coupon.
   * @throws CustomerUserException
   */
    public List<Coupon>getCustomerCouponsByMaxPrice(double maxPrice) throws CustomerUserException {
      if(customerRepo.findById(customerId).getCoupons().isEmpty()){
        throw new CustomerUserException("This customer has no coupons in this price range");
      }
      return customerRepo.findById(customerId).getCoupons().stream().filter((coupon -> coupon.getPrice()<=maxPrice)).collect(Collectors.toList());
    }

  /**
   * This method gives all the details of the customer.
   *
   * @return the customer by the id
   */
    public Customer getCustomerDetails(){
      return customerRepo.findById(customerId);
    }
}
