import classes from "./Company.module.css";
import CompanyHeader from './CompanyHeader';

const Company = () => {
  return (
    <>
      <CompanyHeader></CompanyHeader>
      <main className={classes.main}></main>
    </>
  );
};

export default Company;