package com.project2.project2.Util;

public class Art {
    public static final String localhost="";
}
