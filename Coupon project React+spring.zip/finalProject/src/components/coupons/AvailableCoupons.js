import Card1 from "../UI/Card1";
import styles from "./AvailableCoupon.module.css";


const DUMMY_COUPONS = [{id:1,title:"sushi",description:"10% discount on sushi in all Japanika's stores Bon Apetit",image:"https://media-cdn.tripadvisor.com/media/photo-s/19/3b/00/06/sushi-place.jpg" , price :"30$"},
{id:2,title:"sushi",description:"10% discount on sushi in all Japanika's stores Bon Apetit",image:"https://media-cdn.tripadvisor.com/media/photo-s/19/3b/00/06/sushi-place.jpg",price:"30$"},
{id:1,title:"sushi",description:"10% discount on sushi in all Japanika's stores Bon Apetit",image:"https://media-cdn.tripadvisor.com/media/photo-s/19/3b/00/06/sushi-place.jpg" , price :"30$"},
{id:1,title:"sushi",description:"10% discount on sushi in all Japanika's stores Bon Apetit",image:"https://media-cdn.tripadvisor.com/media/photo-s/19/3b/00/06/sushi-place.jpg" , price :"30$"},
{id:1,title:"sushi",description:"10% discount on sushi in all Japanika's stores Bon Apetit",image:"https://media-cdn.tripadvisor.com/media/photo-s/19/3b/00/06/sushi-place.jpg" , price :"30$"}]

const AvailableCoupons = (props)=>{
    return <div className = {styles.gridContainer}>
    {DUMMY_COUPONS.map(coupon => <Card1 id={coupon.id} key = {coupon.id} title = {coupon.title} description = {coupon.description} price = {coupon.price} image = {coupon.image}/>)}
    </div>
};
export default AvailableCoupons;