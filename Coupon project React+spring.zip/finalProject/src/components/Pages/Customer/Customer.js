import classes from "./Customer.module.css";
import CustomerHeader from './CustomerHeader';

const Customer = () => {
  return (
    <>
      <CustomerHeader></CustomerHeader>
      <main className={classes.main}></main>
    </>
  );
};

export default Customer;