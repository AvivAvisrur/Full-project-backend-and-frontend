package com.project2.project2.Beans;

import com.project2.project2.Login.ClientType;
import lombok.AllArgsConstructor;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.usertype.UserType;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class UserDetails {
    private String userPassword;
    private String userEmail;
    private ClientType clientType;

}
