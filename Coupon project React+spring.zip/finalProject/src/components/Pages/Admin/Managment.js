import { Fragment} from 'react';
import { useHistory } from 'react-router';
import Button from "../../Header/buttons/Button"
import classes from "./Managment.module.css"

const Managment = () => {
    const history = useHistory();
    const addCompanyHandler = ()=>{
        history.push("/addCompany")
    }
    const updateCompanyHandler = ()=>{
        history.push("/updateCompany")
    }
    const deleteCompanyHandler = ()=>{
        history.push("/deleteCompany")
    }
    const updateCustomerHandler = ()=>{
        history.push("/updateCustomer");
    }
    const deleteCustomerHandler = ()=>{
        history.push("/deleteCustomer");
    }

    return (
        <Fragment>
        <div className = {classes.Managment}>
        <div className = {classes.companyManage}>
        <h1>Manage companies</h1>
        <hr/>
        <Button onClick = {addCompanyHandler}>Add company</Button><br/>
        <Button onClick = {updateCompanyHandler}>Update company</Button><br/>
        <Button onClick = {deleteCompanyHandler}>Delete company </Button><br/>
        </div>
        <div className = {classes.customerManage}>
        <h1>Manage Customers</h1>
        <hr/>
        <Button onClick = {updateCustomerHandler}>Update Customer</Button><br/>
        <Button onClick = {deleteCustomerHandler}>Delete Customer </Button><br/>
        </div>
        </div>
        </Fragment>
    );
};

export default Managment;