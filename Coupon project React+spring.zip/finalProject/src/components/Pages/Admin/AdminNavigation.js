import Logout from "../Logout";
import { NavLink } from "react-router-dom";
import classes from "../Admin/AdminNavigation.module.css"
const AdminNavigation = ()=>{

    return (
        <header className ={classes.header} >
        <div className = {classes.buttons}>
        <NavLink className = {classes.button} to = "/managment">Managment</NavLink>
        <Logout/>
        </div>
        </header>
    )
};
export default AdminNavigation