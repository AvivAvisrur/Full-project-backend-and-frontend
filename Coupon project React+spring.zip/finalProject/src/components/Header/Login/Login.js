
import { useState } from "react";
import styles from "./Login.module.css"
import Card from '../../UI/Card';
import Button from "../buttons/Button";
import { Form } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import axios from "axios";
import { FormControl, InputLabel, Select, MenuItem } from "@mui/material";
import { useDispatch } from "react-redux";
import { authActions } from "../../../store/auth-slice";
import jwtDecode from "jwt-decode";



const Login = (props) => {
  const [clientType, setClientType] = useState(null);
  const [password, setPassword] = useState(null);
  const [email, setEmail] = useState(null);
  const dispatch = useDispatch();


  const emailChangeHandler = (event) => {
    setEmail(event.target.value)
  }
  const passwordChangeHandler = (event) => {
    setPassword(event.target.value);
  }

  const clientTypeHandler = (event) => {
    setClientType(event.target.value);
  }

  const submitHandler = (event) => {
    event.preventDefault();
    let url;
    const details = {
      userPassword: password,
      userEmail: email,
      clientType: clientType,
    }
    console.log(details)
    switch (clientType) {
      case "administrator":
        url = "http://localhost:8081/Admin/login"
        break;
      case "company":
        url = "http://localhost:8081/Company/login"
        break;
      case "customer":
        url = "http://localhost:8081/Customer/login"
        break;

      default:
        url = null;
    }

    axios.post(url, details)
      .then((response) => { //jwt
        console.log(response)
        console.log(jwtDecode(response.headers.authorization))
        dispatch(authActions.login(response.headers.authorization))
        console.log(response.headers.authorization);
      })
      .catch(error => {
        console.log(error);
      });
  };

  return (
    <Card className={`${styles.Login}`}>
      <form onSubmit={submitHandler}>
        <div
          className={`${styles.control}`}
        >
          <label htmlFor="email">E-Mail</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={emailChangeHandler}

          />
        </div>
        <div
          className={`${styles.control}`}

        >
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={passwordChangeHandler}

          />
        </div>
        <div>
          <FormControl fullWidth>
            <InputLabel id="demo-simple-select-label">Client Type</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              label="Client Type"
              onChange={clientTypeHandler}
            >
              <MenuItem value={"administrator"} >Administrator</MenuItem>
              <MenuItem value={"company"} >Company</MenuItem>
              <MenuItem value={"customer"} >Customer</MenuItem>
            </Select>
          </FormControl>
        </div>
        <Form.Group className={`mb-3 ${styles.checkBox}`}>
          <Form.Check
            type="checkbox"
            id="disabledFieldsetCheck"
            label="Remember me"
          />
        </Form.Group>
        <p>Not a member? <NavLink to="/sign-up">Sign Up</NavLink></p>
        <div className={styles.actions}>
          <Button type="submit" className={styles.btn}>
            Login
          </Button>
          {props.isClicked && <Button>Cancel</Button>}
        </div>
      </form>
    </Card>
  );
};

export default Login;