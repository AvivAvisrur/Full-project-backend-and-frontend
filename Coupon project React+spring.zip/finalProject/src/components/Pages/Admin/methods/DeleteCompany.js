import DeleteForm from "../../Forms/DeleteForm";

const DeleteCompany = ()=>{
    return <DeleteForm type = "Company" url = "http://localhost:8081/Admin/deleteCompany/"/>
};
export default DeleteCompany;