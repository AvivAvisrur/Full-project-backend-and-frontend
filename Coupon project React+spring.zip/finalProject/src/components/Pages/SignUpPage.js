import { Fragment } from "react";
import SignUp from "./Forms/SignUp";
 

const SignUpPage = () => {
    return (
        <Fragment>
           <SignUp/> 
        </Fragment>
    )

};
export default SignUpPage;