package com.project2.project2.controller;

import com.project2.project2.Beans.Category;
import com.project2.project2.Beans.Coupon;
import com.project2.project2.Beans.UserDetails;
import com.project2.project2.Exceptions.CompanyUserException;
import com.project2.project2.Exceptions.CouponException;
import com.project2.project2.Exceptions.CustomerUserException;
import com.project2.project2.Exceptions.LoginException;
import com.project2.project2.Login.ClientType;
import com.project2.project2.Login.LoginManager;
import com.project2.project2.Service.ClientService;
import com.project2.project2.Service.CompanyService;
import com.project2.project2.Util.JWTutil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



/**
 *
 * This class is in charge of all the VERBS that we use with our external servers.
 * It has 7 VERBS of type POST to add/update/delete/get coupons.
 * It is in charge of handling REST API requests and returning the response.
 *
 */
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RestController
@RequestMapping("/Company")
@RequiredArgsConstructor
public class CompanyController {
    private CompanyService companyService = null;
    private final LoginManager loginManager;
    private final JWTutil jwTutil;


    @PostMapping("/login")
    @ResponseStatus(HttpStatus.OK)
    private ResponseEntity<?>login(@RequestBody UserDetails userDetails /*(HttpServletResponse response*/) throws LoginException {
        try {
            companyService = (CompanyService) loginManager.login(userDetails.getUserEmail(), userDetails.getUserPassword(), userDetails.getClientType());
            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.set("Authorization",jwTutil.generateToken(userDetails));
//            Cookie cookie = new Cookie("token",jwTutil.generateToken(userDetails));
//            cookie.setMaxAge(60*30);
//            cookie.setPath("/");
//            response.addCookie(cookie);
            System.out.println(companyService.getCompanyDetails());
            return ResponseEntity.ok().headers(responseHeaders).body("Welcome back "+companyService.getCompanyDetails().getName());

        } catch (CompanyUserException | CustomerUserException |NullPointerException e) {
            throw new LoginException("incorrect details");
        }
    }
    private HttpHeaders getHeaders(String token) {
        UserDetails userDetails = new UserDetails();
        userDetails.setUserEmail(jwTutil.extractEmail(token));
        System.out.println(jwTutil.extractAllClaims(token).get("clientType"));
        userDetails.setClientType(ClientType.valueOf((String) jwTutil.extractAllClaims(token).get("clientType")));
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Authorization", jwTutil.generateToken(userDetails));
        return httpHeaders;

    }

    /**
     * This verb enable the customer to add coupons  from external server.
     *
     * @param coupon that the company adds.
     * @return ResponseEntity<> with message and HTTP status.
     *
     * @throws CouponException
     */
    @PostMapping("/addCoupon")
    private ResponseEntity<?>addCoupon(@RequestHeader(name="Authorization")String token,@RequestBody Coupon coupon) throws CouponException {
        if(jwTutil.validateToken(token)) {
            try {
                companyService.addCoupon(coupon);
               return ResponseEntity.ok().headers(getHeaders(token)).body("Coupon has been added");
            } catch (CouponException e) {
                throw new CouponException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the admin to update coupon  to the system from external server.
     *
     * @param coupon that we want to update.
     * @return ResponseEntity<> with message and HTTP status.
     * @throws CouponException
     */
    @PostMapping("/updateCoupon")
    private ResponseEntity<?>updateCoupon(@RequestHeader(name="Authorization")String token,@RequestBody Coupon coupon) throws CouponException {
        if (jwTutil.validateToken(token)) {
            companyService.updateCoupon(coupon);
            return ResponseEntity.ok().headers(getHeaders(token)).body("Coupon has been updated");
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the customer to delete coupon  from external server.
     *
     * @param id of the coupon we deleting.
     * @return ResponseEntity<> with message and HTTP status.
     * @throws CouponException
     */
    @PostMapping("/deleteCoupon/{couponID}")
    private ResponseEntity<?>deleteCoupon(@RequestHeader(name = "Authorization")String token,@PathVariable long id) throws CouponException {
        if(jwTutil.validateToken(token)) {
            companyService.deleteCoupon(id);
            return ResponseEntity.ok().headers(getHeaders(token)).body("Coupon has been deleted");
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable  to get all coupons of a specific company from external server.
     *
     * @return ResponseEntity<> with list of all  coupons of the company and HTTP status.
     * @throws CompanyUserException
     */
    @PostMapping("/getCompanyCoupons")
    private ResponseEntity<?>getCompanyCoupons(@RequestHeader(name = "Authorization")String token) throws CompanyUserException {
        if(jwTutil.validateToken(token)) {
            try {
                return ResponseEntity.ok().headers(getHeaders(token)).body(companyService.getCompanyCoupons());
            } catch (CompanyUserException e) {
                throw new CompanyUserException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable to get all coupons by category of a specific company from external server.
     * @param category of the coupon
     * @return ResponseEntity<> with list of all coupons from the same category of a company and HTTP status.
     * @throws CompanyUserException
     */
    @PostMapping("/getCompanyCouponsByCategory/{category}")
    private ResponseEntity<?>getCompanyCouponsByCategory(@RequestHeader(name = "Authorization")String token,@PathVariable Category category) throws CompanyUserException {
        if(jwTutil.validateToken(token)) {
            try {
                return ResponseEntity.ok().headers(getHeaders(token)).body(companyService.getCompanyCouponsByCategory(category));
            } catch (CompanyUserException e) {
                throw new CompanyUserException(e.getMessage());

            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable  to get all coupons by max price of the coupon from the system from external server.
     * @param maxPrice of the coupon
     * @return ResponseEntity<> with list of all coupons with max price and HTTP status.
     * @throws CompanyUserException
     */
    @PostMapping("getCompanyCouponsByMaxPrice/{maxPrice}")
    private ResponseEntity<?>getCompanyCouponsByMaxPrice(@RequestHeader(name = "Authorization")String token,@PathVariable double maxPrice) throws CompanyUserException {
        if(jwTutil.validateToken(token)) {
            try {
                return ResponseEntity.ok().headers(getHeaders(token)).body(companyService.getCompanyCouponsByMaxPrice(maxPrice));
            } catch (CompanyUserException e) {
                throw new CompanyUserException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable  to get all company details from the system from external server.
     *
     * @return ResponseEntity<> with company details and HTTP status.
     * @throws CompanyUserException
     */
    @PostMapping("/getCompanyDetail")
    private ResponseEntity<?>getCompanyDetails(@RequestHeader(name = "Authorization")String token){
        if(jwTutil.validateToken(token)) {
            return ResponseEntity.ok().headers(getHeaders(token)).body(companyService.getCompanyDetails());
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

}
