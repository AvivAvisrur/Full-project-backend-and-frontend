import classes from './Managment.module.css';

const Managment = () => {
    return (
        <button>Managment</button>
    );
};

export default Managment;