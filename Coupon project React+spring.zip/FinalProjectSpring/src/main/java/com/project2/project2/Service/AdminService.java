package com.project2.project2.Service;

import com.project2.project2.Beans.Company;

import com.project2.project2.Beans.Coupon;
import com.project2.project2.Beans.Customer;
import com.project2.project2.Exceptions.CompanyUserException;
import com.project2.project2.Exceptions.CouponException;
import com.project2.project2.Exceptions.CustomerUserException;


import com.project2.project2.Exceptions.LoginException;
import com.project2.project2.Util.ColorPrint;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;


import java.util.List;

/**
 * This class extends another abstract class.
 * This class is in charge of all the logic of all the function of Admin type.
 * It has 4 attributes . login method that gives access to only authorized user to all the methods below.
 *
 */

@Service
public class AdminService extends ClientService {
    @Autowired
    private CustomerService cus;
    @Autowired
    private CompanyService cs;
    private final String EMAIL = "admin@admin.com";
    private final String PASSWORD = "admin";


    /**
     * This method enable the company to login to the system.
     *
     * @param email    the email of the admin who try to log in.
     * @param password the password of the admin account.
     * @return true if the email and password is ok and false if not.
     */
    @Override
    public boolean login(String email, String password) throws LoginException {
        if(email.equals(EMAIL)&&password.equals(PASSWORD)){
            System.out.println(ColorPrint.ANSI_BLUE+"Welcome back admin!"+ColorPrint.ANSI_RESET);
        }else{
            throw new LoginException("Something went wrong!");
        }
        return email.equals(EMAIL)&&password.equals(PASSWORD);
    }

    /**
     * This method enable the admin to add company  to the system.
     *
     * @param company the company we adding.
     * @throws CompanyUserException
     */
    public void addCompany(Company company) throws CompanyUserException {
        try {
            companyRepo.save(company);
            System.out.println("Company added successfully");
        }catch (DataIntegrityViolationException e){
            throw new CompanyUserException("Company already exists!");
        }
    }

    /**
     * This method allow the admin to update company  to the system.
     *
     * @param company the company we updating.
     * @throws CompanyUserException
     */
    public void updateCompany(Company company) throws CompanyUserException {
        if(!companyRepo.existsById(company.getId())){
            throw new CompanyUserException("Company does not exists!");
        }
        Company updateCompany = companyRepo.findById(company.getId());
        updateCompany.setEmail(company.getEmail());
        updateCompany.setPassword(company.getPassword());
        companyRepo.saveAndFlush(updateCompany);
        System.out.println("Updated done!");
    }

    /**
     * This method allow the admin to delete company  from the system.
     *
     * @param companyID the id of the specific company we want to delete.
     * @throws CouponException
     * @throws CompanyUserException
     */
    public void deleteCompany(long companyID) throws CouponException, CompanyUserException {
        if(!companyRepo.existsById(companyID)){
            throw new CompanyUserException("Company not exists!");
        }
        List<Coupon>coupons = couponRepo.findByCompanyId(companyID);
        for (Coupon item : coupons) {
            cs.deleteCoupon(item.getId());
        }
        companyRepo.deleteById(companyID);
        System.out.println("Company deleted!");
    }

    /**
     * This method allow the admin to get all the  companies  from the system.
     *
     * @return all the companies from the DB
     * @throws CompanyUserException
     */
    public List<Company>getAllCompanies() throws CompanyUserException {
        if(companyRepo.findAll().isEmpty()){
            throw new CompanyUserException("There is no companies in the system!");
        }
        return companyRepo.findAll();
    }

    /**
     * This method allow the admin to get one  company  from the system.
     *
     * @param companyId the id of the specific company we want to get.
     * @return the company that the admin asked for.
     * @throws  CompanyUserException
     */
    public Company getCompanyById(long companyId) throws CompanyUserException {
        if (!companyRepo.existsById(companyId)){
            throw new CompanyUserException("This company id is not in the sysem!");
        }
        return companyRepo.findById(companyId);
    }

    /**
     * This method allow the admin to add customer  to the system.
     *
     * @param customer the customer we adding.
     * @throws CustomerUserException
     */


    /**
     * This method allow the admin to update customer  to the system.
     *
     * @param customer the customer we updating.
     * @throws CustomerUserException
     */
    public void updateCustomer(Customer customer) throws CustomerUserException {
        if (!customerRepo.existsById(customer.getId())) {
            throw new CustomerUserException("Customer not found");
        }
        Customer updateLecturer = customerRepo.findById(customer.getId());
        updateLecturer.setFirstName(customer.getFirstName());
        updateLecturer.setLastName(customer.getLastName());
        updateLecturer.setEmail(customer.getEmail());
        updateLecturer.setPassword(customer.getPassword());
        customerRepo.saveAndFlush(updateLecturer);
        System.out.println("Updated done!");
    }

    /**
     * This method allow the admin to delete customer  from the system.
     *
     * @param customerID the id of the specific customer we want to delete.
     * @throws CustomerUserException
     */
    public void deleteCustomer(long customerID) throws CustomerUserException {
        if(!customerRepo.existsById(customerID)){
            throw new CustomerUserException("User is not found cant delete");
        }
        customerRepo.deleteById(customerID);
        System.out.println("Customer deleted!");
    }

    /**
     * This method allow the company to delete coupon  from the system.
     *
     * @param id of the coupon.
     */
    public void deleteCoupon(long id) {
        couponRepo.deleteById(id);

    }
    /**
     * This method allow the admin to get all the customers from the system.
     *
     * @return all the customers in the system.
     * @throws CustomerUserException
     */
    public List<Customer> getAllCustomers() throws CustomerUserException {
        if(customerRepo.findAll().isEmpty()){
            throw new CustomerUserException("There is no customers registered");
        }
        return customerRepo.findAll();
    }

    /**
     * This method allow the admin to get one customer by his id from the system.
     *
     * @param customerID the id of the specific company we want to update.
     * @return the customer the admin asked for.
     * @throws CustomerUserException
     */
    public Customer getOneCustomer(long customerID) throws CustomerUserException {
        if(customerRepo.existsById(customerID)){
            throw new CustomerUserException("This customer is not registered");
        }
        return customerRepo.findById(customerID);
    }




}
