import { Fragment } from "react";
import {Card,Button} from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.css"
import styles from "./Card.module.css"

const Card1 = (props)=>{
  return <Fragment>
    <Card className={`${styles.card} ${styles.gridItem}`} style={{ width: '30rem' }}>
  <Card.Img variant="top" src={props.image} />
  <Card.Body>
    <Card.Title>{props.title}</Card.Title>
    <Card.Text>
      {props.description}
    </Card.Text>
    <Card.Text>
      Price: {props.price}
    </Card.Text>
    <Button variant="primary">Buy</Button>
  </Card.Body>
</Card>

  </Fragment>
};
export default Card1;