package com.project2.project2.controller;

import com.project2.project2.Beans.Company;
import com.project2.project2.Beans.Customer;
import com.project2.project2.Beans.UserDetails;
import com.project2.project2.Exceptions.CompanyUserException;
import com.project2.project2.Exceptions.CouponException;
import com.project2.project2.Exceptions.CustomerUserException;
import com.project2.project2.Exceptions.LoginException;
import com.project2.project2.Login.ClientType;
import com.project2.project2.Login.LoginManager;
import com.project2.project2.Service.AdminService;
import com.project2.project2.Util.JWTutil;
import lombok.RequiredArgsConstructor;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * This class is in charge of all the VERBS that we use with our external servers.
 * It has 10 VERBS of type POST to add/update/delete/get company and customer.
 * It is in charge of handling REST API requests and returning the response.
 *
 */
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RestController
@RequestMapping("/Admin")
@RequiredArgsConstructor
public class AdminController {
    private final AdminService adminService;
    private final JWTutil jwTutil;
    private final LoginManager loginManager;




    @PostMapping("/login")
    @ResponseStatus(HttpStatus.OK)
    private ResponseEntity<?>login(@RequestBody UserDetails userDetails /*(HttpServletResponse response*/) throws LoginException {
        try {
              loginManager.login(userDetails.getUserEmail(), userDetails.getUserPassword(), userDetails.getClientType());
            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.set("Authorization",jwTutil.generateToken(userDetails));
//            Cookie cookie = new Cookie("token",jwTutil.generateToken(userDetails));
//            cookie.setMaxAge(60*30);
//            cookie.setPath("/");
//            response.addCookie(cookie);
            return ResponseEntity.ok().headers(responseHeaders).body("Welcome back admin");

        } catch (CompanyUserException | CustomerUserException e) {
            throw new LoginException("incorrect details");
        }
    }



        private HttpHeaders getHeaders(String token) {
            UserDetails userDetails = new UserDetails();
            userDetails.setUserEmail(jwTutil.extractEmail(token));
            System.out.println(jwTutil.extractAllClaims(token).get("clientType"));
            userDetails.setClientType(ClientType.valueOf((String) jwTutil.extractAllClaims(token).get("clientType")));
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set("Authorization", jwTutil.generateToken(userDetails));
            return httpHeaders;
        }

    /**
     * This verb enable the admin to add company  to the system from external server.
     *
     * @param company the company we adding.
     * @return ResponseEntity<> with message and HTTP status.
     *
     * @throws CompanyUserException
     */



    @PostMapping("/addCompany")
    @ResponseStatus(HttpStatus.ACCEPTED)
    private ResponseEntity<?>addCompany(@RequestHeader(name = "Authorization")String token , @RequestBody Company company) throws CompanyUserException {
        System.out.println(token);
        System.out.println(company);
        if(jwTutil.validateToken(token)) {
            try {
                adminService.addCompany(company);
            } catch (DataIntegrityViolationException e) {
                throw new CompanyUserException(e.getMessage());
            }
            return ResponseEntity.ok().headers(getHeaders(token)).body("Company has been added");
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the admin to update company  to the system from external server.
     *
     * @param company the company we adding.
     * @return ResponseEntity<> with message and HTTP status.
     * @throws CompanyUserException
     */
    @PostMapping("/updateCompany")
    private ResponseEntity<?>updateCompany(@RequestHeader(name = "Authorization")String token, @RequestBody Company company) throws CompanyUserException {
        if(jwTutil.validateToken(token)) {
            try {
                adminService.updateCompany(company);
            } catch (CompanyUserException e) {
                throw new CompanyUserException(e.getMessage());
            }
            return ResponseEntity.ok().headers(getHeaders(token)).body("Company has been updated");
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the admin to delete company  to the system from external server.
     *
     * @param id the company we adding.
     * @return ResponseEntity<> with message and HTTP status.
     * @throws CompanyUserException
     */
    @PostMapping("/deleteCompany/{id}")
    private ResponseEntity<?>deleteCompany(@RequestHeader(name = "Authorization")String token,@PathVariable long id) throws CompanyUserException {
        if(jwTutil.validateToken(token)) {
            try {
                adminService.deleteCompany(id);
            } catch (CouponException | NullPointerException | CompanyUserException e) {
                throw new CompanyUserException(e.getMessage());
            }
            return ResponseEntity.ok().headers(getHeaders(token)).body("Company has been deleted");
        }
        return new ResponseEntity<>("Invalid Token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the admin to get all companies from the system from external server.
     *
     * @return ResponseEntity<> with list of all companies and HTTP status.
     * @throws CompanyUserException
     */
    @PostMapping("/getAllCompany")
    private ResponseEntity<?>getAllCompanies(@RequestHeader(name = "Authorization")String token) throws CompanyUserException {
        if(jwTutil.validateToken(token)) {
            try {

               return ResponseEntity.ok().headers(getHeaders(token)).body(adminService.getAllCompanies());
            } catch (CompanyUserException e) {
                throw new CompanyUserException("There is no companies in the system");
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the admin to get 1 company from the system from external server.
     * @param id of the company
     * @return ResponseEntity<> with company and HTTP status.
     * @throws CompanyUserException
     */
    @PostMapping("/getOneCompany/{id}")
    private ResponseEntity<?>getOneCompany(@RequestHeader(name = "Authorization")String token,@PathVariable long id) throws CompanyUserException {
        if(jwTutil.validateToken(token)) {
            try {

                return  ResponseEntity.ok().headers(getHeaders(token)).body(adminService.getCompanyById(id));

            } catch (CompanyUserException e) {
                throw new CompanyUserException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }
    /**
     * This verb enable the admin to update customer from the system from external server.
     * @param customer that we want to update.
     * @return ResponseEntity<> with message and HTTP status.
     * @throws CustomerUserException
     */
    @PostMapping("/updateCustomer")
    private ResponseEntity<?>updateCustomer(@RequestHeader(name="Authorization")String token,@RequestBody Customer customer) throws CustomerUserException {
        System.out.println(token);
        System.out.println(customer);
        if(jwTutil.validateToken(token)) {
            try {
                adminService.updateCustomer(customer);
                return ResponseEntity.ok().headers(getHeaders(token)).body("Customer has been updated");
            } catch (CustomerUserException e) {
                throw new CustomerUserException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the admin to delete customer from the system from external server.
     * @param id of the customer we want to erase.
     * @return ResponseEntity<> with message and HTTP status.
     * @throws CustomerUserException
     */
    @PostMapping("/deleteCustomer/{id}")
    private ResponseEntity<?>deleteCustomer(@RequestHeader(name="Authorization")String token,@PathVariable long id) throws CustomerUserException {
       if(jwTutil.validateToken(token)) {
           try {
               adminService.deleteCustomer(id);
               return ResponseEntity.ok().headers(getHeaders(token)).body("Customer has been deleted");
           } catch (CustomerUserException e) {
               throw new CustomerUserException(e.getMessage());
           }
       }
       return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the admin to get all customers from the system from external server.
     *
     * @return ResponseEntity<> with list of all customers and HTTP status.
     * @throws CustomerUserException
     */
    @PostMapping("/getAllCustomers")
    private ResponseEntity<?>getAllCustomers(@RequestHeader(name="Authorization")String token) throws CustomerUserException {
        if(jwTutil.validateToken(token)) {
            try {

                return ResponseEntity.ok().headers(getHeaders(token)).body(adminService.getAllCustomers());

            } catch (CustomerUserException e) {
                throw new CustomerUserException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }

    /**
     * This verb enable the admin to get 1 customer from the system from external server.
     * @param id of the customer we want to get.
     * @return ResponseEntity<> with customer and HTTP status.
     * @throws CustomerUserException
     */
    @PostMapping("/getOneCustomer/{id}")
    private ResponseEntity<?>getOneCustomer(@RequestHeader(name="Authorization")String token,@PathVariable long id) throws CustomerUserException {
        if(jwTutil.validateToken(token)) {
            try {

                return  ResponseEntity.ok().headers(getHeaders(token)).body(adminService.getOneCustomer(id));
            } catch (CustomerUserException e) {
                throw new CustomerUserException(e.getMessage());
            }
        }
        return new ResponseEntity<>("Invalid token",HttpStatus.UNAUTHORIZED);
    }
}
