package com.project2.project2.Exceptions;

public class CompanyUserException extends Exception{
    public CompanyUserException() {
    }

    public CompanyUserException(String message) {
        super(message);
    }
}
