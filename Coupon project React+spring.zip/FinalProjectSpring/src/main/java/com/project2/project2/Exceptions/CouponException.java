package com.project2.project2.Exceptions;

public class CouponException extends Exception{
    public CouponException() {
    }
    public CouponException(String message) {
        super((message));
    }
}
