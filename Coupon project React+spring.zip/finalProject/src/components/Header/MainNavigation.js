import { useState } from "react";
import Login from "./Login/Login";
import classes from './MainNavigation.module.css';
import "bootstrap/dist/css/bootstrap.css";
import {
  Nav,
  Navbar,
  Button,
} from "react-bootstrap";
import { NavLink } from "react-router-dom";



const HeaderDropDown = () => {
  const [isClicked, setIsClicked] = useState(false);

  const renderLogin = () => {
    return (<div className={classes.LoginContainer}>
      <Login />
    </div>);
  };

  return (
    <>
    {isClicked ? renderLogin() : null}
    <Navbar variant="dark" bg="#200135;" expand="lg">
      <Navbar.Toggle aria-controls="navbarScroll" />
      <Navbar.Collapse id="navbarScroll">
        <Nav
          className="mr-auto my-2 my-lg-0"
          style={{ maxHeight: "100px" }}
          navbarScroll
        >
          <NavLink className ={classes.HeaderButton} to="/home">Home</NavLink>
          <Button className = {classes.HeaderButton} onClick={() => setIsClicked(!isClicked)}>Sign In</Button>
          <NavLink className = {classes.HeaderButton} to="/about-us">About us</NavLink>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
    </>
  );
};

export default HeaderDropDown;
